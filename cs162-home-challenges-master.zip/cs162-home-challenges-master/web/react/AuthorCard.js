import React from "react"

function AuthorCard(props) {
    return(
        <div className="author-card">
            <img src={props.img}/>
            <h3>{props.name}</h3>
            <p><a href={"mailto:" + props.email}>{props.email}</a></p>
            <p>{props.desc}</p>
        </div>
    )
}

export default AuthorCard