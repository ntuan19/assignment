import AuthorCard from "./AuthorCard.js"

function Author() {
  return (
    <div className="authors">
      <h2 className="authors-title">WHO MADE THIS?</h2>
      <div className="pane">
        <AuthorCard 
          name="Hanaka Saito"
          img="https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png"
          email="hanaka.saito@minerva.kgi.edu"
          desc="Insert text here..."
        />
        <AuthorCard 
          name="Alex Bulintis"
          img="https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png"
          email="bulintis@minerva.kgi.edu"
          desc="Insert text here..."
        />
        <AuthorCard 
          name="Chloe Gabrielle Go"
          img="https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png"
          email="go@minerva.kgi.edu"
          desc="Insert text here..."
        />
        <AuthorCard 
          name="Tuan Nguyen"
          img="https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png"
          email="nanhtuan.fly@minerva.kgi.edu"
          desc="Insert text here..."
        />
        <AuthorCard 
          name="Usama Puri"
          img="https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png"
          email="usamapuri@minerva.kgi.edu"
          desc="Insert text here..."
        />
        <AuthorCard 
          name="Valdrin Jonuzi"
          img="https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png"
          email="valdrinj@minerva.kgi.edu"
          desc="Insert text here..."
        />
      </div>
    </div>
  );
}

export default Author;