# In this file you can put any configuration for pytest.
# Pytest is used in this project to run all the unit tests.
# For a simple example like this we can leave it blank.
